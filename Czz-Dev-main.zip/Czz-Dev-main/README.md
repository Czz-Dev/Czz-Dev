<img align="center" style="margin-bottom:100px" width=100% src="https://camo.githubusercontent.com/506dd10e735bde43dc8b33bdef28171874232015508c55574eadeb5416282862/68747470733a2f2f6d656469612e646973636f72646170702e6e65742f6174746163686d656e74732f313038373035353231363637323737323134372f313136353833393934313037393637303832352f427265616b5f646f776e5f7468655f7363726970745f696e746f5f696e646976696475616c5f7363656e65735f616e645f6964656e746966795f7468655f6b65795f656c656d656e74732e2e706e673f65783d36353438353030652669733d363533356462306526686d3d62613463346437313461633063633465343037333036626165663835343937653038343334663231663266366539376366363066356635383561376661366135263d2677696474683d393630266865696768743d323735" />
&nbsp;&nbsp;&nbsp;

<div style="background-color: #00FF00; text-align: center;">
    <h1 align="center">Welcome to My GitHub Profile!👋</h1>
</div>
<div style="background-color: #00FF00; text-align: center;">
    <h1 align="center">Bem-vindo ao Meu Perfil do GitHub!👋</h1>
</div>



 &nbsp;
 &nbsp;

## Minhas Habilidades

#### Stack Principal:

![Python](https://img.shields.io/badge/Python-14354C?style=for-the-badge&logo=python&logoColor=white)&nbsp;
![JavaScript](https://img.shields.io/badge/JavaScript-F7DF1E?style=for-the-badge&logo=javascript&logoColor=black)&nbsp;
![TypeScript](https://img.shields.io/badge/TypeScript-007ACC?style=for-the-badge&logo=typescript&logoColor=white)&nbsp;
![HTML](https://img.shields.io/badge/HTML5-E34F26?style=for-the-badge&logo=html5&logoColor=white)&nbsp;
![CSS](https://img.shields.io/badge/CSS3-1572B6?style=for-the-badge&logo=css3&logoColor=white)&nbsp;
![Flask](https://img.shields.io/badge/Flask-000000?style=for-the-badge&logo=flask&logoColor=white)&nbsp;
![React.js](https://img.shields.io/badge/React-20232A?style=for-the-badge&logo=react&logoColor=61DAFB)&nbsp;
![RabbitMQ](https://img.shields.io/badge/RabbitMQ-%23FF6600.svg?&style=for-the-badge&logo=rabbitmq&logoColor=white)&nbsp;
![Git](https://img.shields.io/badge/GIT-E44C30?style=for-the-badge&logo=git&logoColor=white)&nbsp;
![Lua](https://img.shields.io/badge/Lua-2C2D72?style=for-the-badge&logo=lua&logoColor=white)&nbsp;



<img src="https://cdn.discordapp.com/attachments/1087055216672772147/1165845640476110868/345fgf.png?ex=6548555d&is=6535e05d&hm=504bb4b74e9329ddbdcedbeeeb4f848180cd2d19682cf9b966f43ad296d6f0fd&" min-width="400px" max-width="400px" width="400px" align="right" alt="Computador iuriCode">

#### Stack Secundária:

![C#](https://img.shields.io/badge/C%23-239120?style=for-the-badge&logo=c-sharp&logoColor=white)&nbsp;
![R](https://img.shields.io/badge/R-276DC3?style=for-the-badge&logo=r&logoColor=white)&nbsp;
![Unity](https://img.shields.io/badge/Unity-100000?style=for-the-badge&logo=unity&logoColor=white)&nbsp;
![Django](https://img.shields.io/badge/Django-092E20?style=for-the-badge&logo=django&logoColor=white)&nbsp;

#### Estudando atualmente:

![Google Cloud](https://img.shields.io/badge/Google_Cloud-4285F4?style=for-the-badge&logo=google-cloud&logoColor=white)&nbsp;
![Kubernetes](https://img.shields.io/badge/Kubernetes-4285F4?style=for-the-badge&logo=kubernetes&logoColor=white)&nbsp;

#### Bancos de Dados:

![MongoDB](https://img.shields.io/badge/MongoDB-4EA94B?style=for-the-badge&logo=mongodb&logoColor=white)&nbsp;
![PostgreSQL](https://img.shields.io/badge/PostgreSQL-316192?style=for-the-badge&logo=postgresql&logoColor=white)&nbsp;

#### Ferramentas de Estação de Trabalho:

![VS Code](https://img.shields.io/badge/VS%20Code-4285F4?style=for-the-badge&logo=vscode&logoColor=white)&nbsp;
![Asana](https://img.shields.io/badge/Asana-E44C30?style=for-the-badge&logo=asana&logoColor=white)&nbsp;
![Notion](https://img.shields.io/badge/Notion-000000?style=for-the-badge&logo=notion&logoColor=white)&nbsp;
![Slack](https://img.shields.io/badge/Slack-4A154B?style=for-the-badge&logo=slack&logoColor=white)&nbsp;
![Ubuntu](https://img.shields.io/badge/Ubuntu-E95420?style=for-the-badge&logo=ubuntu&logoColor=white)&nbsp;

&nbsp;
&nbsp;


## Contatos:

<div> 
<a href="https://www.instagram.com/031.carlos_cz" target="_blank"><img src="https://img.shields.io/badge/-Instagram-%23E4405F?style=for-the-badge&logo=instagram&logoColor=white">
</a>
<a href = "mailto:contato.carlos.hps981@gmail.com"> <img src="https://img.shields.io/badge/-Gmail-%23333?style=for-the-badge&logo=gmail&logoColor=white" target="_blank"></a>

<a href="https://www.roblox.com/users/123456789/profile" target="_blank">
  <img src="https://img.shields.io/badge/-Roblox-02AAB0?style=for-the-badge&logo=roblox&logoColor=white" target="_blank">
</a>
</div>&nbsp;&nbsp;
<a href="https://discordapp.com/users/C.%238705" target="_blank">
  <img src="https://img.shields.io/badge/-Discord-7289DA?style=for-the-badge&logo=discord&logoColor=white" target="_blank">
</a>
</div>&nbsp;&nbsp;

 

  
  
<img width=100% src="https://capsule-render.vercel.app/api?type=waving&color=00FF00&height=120&section=footer"/>
